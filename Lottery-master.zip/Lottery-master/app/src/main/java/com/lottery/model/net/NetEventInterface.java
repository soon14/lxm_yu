package com.lottery.model.net;

public interface NetEventInterface {
    void onNetChange(int netMobile);
}