package com.lottery.constant;

public class Constant {


//    public static final String Url = "http://www.08cpapp.com/Lottery_server/check_and_get_url.php?type=android&show_url=20178837";

//    public static final String Url = "http://118.184.101.237/Lottery_server/public/kaiguan/Interface/getValue?type=android&appid=w100113";

    public static final String Url = "http://www.08cpapp.com/Lottery_server/check_and_get_url.php?type=android&appid=20178825";


    public static final String LOGIN = "fist";
    public static final String DASHEN = "http://www.310win.com/Recommend/AjaxForTj.ashx?n=0.6403141233914953&action=GetTjList&Type=1&SubType=0&OrderType=1&PageIndex=0&PageSize=10";
    //双色球
    public static final String SHUANGSEQIU_ZIXUN = "http://5.9188.com/predict/ssq/";
    //大乐透
    public static final String DALETOU_ZIXUN = "http://5.9188.com/predict/dlt/";
    //双色球
    public static final String DALETOU = "http://5.9188.com/predict/";
    //时时彩
    public static final String SHISHICAI = "http://112.74.102.204:86/m/tool.html";
    //澳客彩票
            public static final String AOKEKAIJIANG="http://www.okooo.com/";
    //主页
//    public static final String ZHANJI = "http://vipc.cn";
//    public static final String ZHANJI = "https://daren.vipc.cn/";
    public static final String OKKAIJIANG = "https://qs.888.qq.com/m_qq/lot.live.html?vb2ctag=4_2089_3_2834#lot.live.index=all";
    //双色球奖金计算器
    public static final String JIANGJINJISUAN = "https://vipc.cn/ssq/calculator?fr=shareToWeixinTimeline";
    //双色球资讯
    public static final String ZHIBO = "https://vipc.cn/lottery/ssq";
    //开奖
    public static final String WCKAIJIANG = "https://vipc.cn/results?in=home_tools_0#hot";
    //500球类直播
    public static final String QIULEIZHIBO = "http://live.m.500.com/center/football?from=app_bet";
    //
    public static final String ZST="http://m.500.com/datachart/";
    //彩票知识
    public static final String ZHISHI="http://m.500.com/info/zhishi/";
    //彩票知识
    public static final String KAIJIANG="http://m.55128.cn/#/lottery";

    //备用网址http://www.sporttery.cn/wap/  图标http://www.17sucai.com/pins/tag/6212.html  http://m.500.com/
    public static final String live="http://live.m.500.com/home/zq/crazybet/cur?render=local";

    public static final String LIVE360="http://m.cp.360.cn/live/jclq";





}
