package com.lottery.model;

public interface NetEventInterface {
    void onNetChange(int netMobile);
}
