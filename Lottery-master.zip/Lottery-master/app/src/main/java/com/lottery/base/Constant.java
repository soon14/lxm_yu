package com.lottery.base;

/**
 * @author: LiuJinrui
 * @email: liujinrui@qdcftx.com
 * @time: 2017/12/7 17:26
 * @description:
 */
public class Constant {

    public  static  final String RESPONSE_SUCCESS="0000";
}
