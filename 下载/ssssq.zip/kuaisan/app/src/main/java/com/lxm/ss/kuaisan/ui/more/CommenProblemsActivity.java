package com.lxm.ss.kuaisan.ui.more;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.lxm.ss.kuaisan.R;
import com.lxm.ss.kuaisan.base.BaseActivity;

public class CommenProblemsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commen_problems);
    }
}
