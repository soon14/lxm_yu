package club.fromfactory.baselibrary.view.recyclerview;

/**
 * Created by lxm on 2017/9/6.
 */

public interface RecyclerAction {
    void onAction();
}
