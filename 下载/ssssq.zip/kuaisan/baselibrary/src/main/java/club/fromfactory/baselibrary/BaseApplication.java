package club.fromfactory.baselibrary;

/**
 * Created by lxm on 2017/9/7.
 */

public class BaseApplication {
}
