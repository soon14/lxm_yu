package club.fromfactory.okhttp.httputil;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Response;

/**
 * Created by lxm on 2017/6/20.
 */

public class LoggerInterceptor implements Interceptor {


    @Override
    public Response intercept(Chain chain) throws IOException {

        return null;
    }
}
