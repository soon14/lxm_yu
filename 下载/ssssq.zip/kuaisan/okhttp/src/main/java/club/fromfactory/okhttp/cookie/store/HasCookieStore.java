package club.fromfactory.okhttp.cookie.store;

public interface HasCookieStore
{
    CookieStore getCookieStore();
}
